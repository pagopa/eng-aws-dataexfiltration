import json, time, boto3, botocore, os, re
from ipaddress import IPv4Interface
from datetime import datetime, timedelta

ACL_ID = os.getenv('ACL_ID')
#ACL_ID = os.getenv('ACL_ID')
TIMEOUT_TABLE_NAME = os.getenv('TIMEOUT_TABLE_NAME')
RULE_CONFIG_JSON = os.getenv('RULE_CONFIG_JSON')
RULE_CONFIG = json.loads(RULE_CONFIG_JSON)
print(json.dumps(RULE_CONFIG, default=str))
for pattern, config in RULE_CONFIG.items():
    config['regex'] = re.compile(pattern)

ec2 = boto3.client('ec2')
ddb = boto3.client('dynamodb')

def get_rule_config(domain:str) -> str:
    """Get the config for regex pattern that matches domain."""
    for pattern, config in RULE_CONFIG.items():
        regex = config['regex']
        if regex.match(domain):
            print(f'{domain} matched {pattern}')
            return config    
    print(f'using defaults for {domain}')
    return RULE_CONFIG['default']

def get_network(ip_address, netmask) -> str:
    """Return network with prefix for IP address."""
    interface = IPv4Interface(f'{ip_address}/{netmask}')
    return interface.network.with_prefixlen

def modify_network_acl(acl_id=ACL_ID, add_entries=None, remove_entries=None):
    if not add_entries and not remove_entries:
        return
    if add_entries and remove_entries:
        raise Error('not allowed to add and remove entries at the same time')

    # Removing entries
    if remove_entries:
        for entry_id, cidr in remove_entries.items():
            try:
                ec2.delete_network_acl_entry(
                    NetworkAclId=acl_id,
                    RuleNumber=int(entry_id),
                    Egress=True
                )
            except botocore.exceptions.ClientError as error:
                print(error)

    # Adding entries
    if add_entries:
        for entry_id, cidr in add_entries.items():
            try:
                ec2.create_network_acl_entry(
                    NetworkAclId=acl_id,
                    RuleNumber=int(entry_id),
                    Protocol='6',  # "-1" means all traffic
                    PortRange={'From': 443, 'To': 443},
                    RuleAction='allow',
                    Egress=True,
                    CidrBlock=cidr['Cidr']
                )
            except botocore.exceptions.ClientError as error:
                print(error)

def get_network_acl_entries(acl_id):
    """Return network ACL entries."""
    response = ec2.describe_network_acls(NetworkAclIds=[acl_id])
    return response['NetworkAcls'][0]['Entries']

def get_highest_rule_number(entries):
    """Find the highest rule number in the current NACL entries starting from 100, excluding '*'."""
    rule_numbers = [entry['RuleNumber'] for entry in entries if isinstance(entry['RuleNumber'], int) and entry['RuleNumber'] >= 100 and entry['RuleNumber'] <= 32766 ]
    return max(rule_numbers, default=100)

def get_answers(records) -> dict:
    """Find the latest timestamp for each network."""
    default_entry = {
        'expire_ts': 0,
        'fqdn': []
    }
    entries = {}
    for record in records:
        query = json.loads(record['body'])

        query_domain = query['query_name']
        rule_config = get_rule_config(query_domain)
        netmask = rule_config['netmask']
        ttl_minutes = rule_config['ttl_minutes']

        query_dt = datetime.fromisoformat(query['query_timestamp'])
        query_ttl_dt = query_dt + timedelta(minutes=ttl_minutes)
        query_ttl_ts = query_ttl_dt.timestamp()

        # update the map with latest TTL for network

        for answer in query['answers']:
            if answer['Type'] != 'A':
                continue

            cidr = get_network(answer['Rdata'], netmask)
            current_entry = entries.get(cidr, default_entry)
            if current_entry['expire_ts'] < query_ttl_ts:
                fqdns = set(current_entry['fqdn'])
                fqdns.add(query_domain)
                entries[cidr] = {
                    'expire_dt': query_ttl_dt.isoformat(),
                    'expire_ts': int(query_ttl_ts),
                    'ttl_minutes': ttl_minutes,
                    'fqdn': list(fqdns),
                }

    return entries

def delete_expired_items():
    """Delete items with expired TTL."""
    now = datetime.utcnow().replace(tzinfo=None)
    now_ts = int(now.timestamp())
    result = ddb.scan(
        TableName=TIMEOUT_TABLE_NAME,
        ProjectionExpression='cidr',
        FilterExpression='expire_ts < :now_ts',
        ExpressionAttributeValues={':now_ts': {'N': str(now_ts)}}
    )

    items = result.get('Items', None)

    # TODO: batch_write_item
    for item in items:
        cidr = item['cidr']['S']
        if cidr == '10.0.0.0/16' or cidr == '0.0.0.0/0':
            continue  # Skip deletion for this CIDR
        print(f'deleting item: {item}')
        result = ddb.delete_item(
            TableName=TIMEOUT_TABLE_NAME,
            Key=item
        )

def get_latest_items(max_items: int) -> None:
    """Return list of latest items sorted by TTL."""
    result = ddb.scan(
        TableName=TIMEOUT_TABLE_NAME
    )

    def get_expire_ts(item):
        return int(item['expire_ts']['N'])

    items = result.get('Items', [])
    sorted_items = sorted(items, key=get_expire_ts, reverse=True)
    return sorted_items[:max_items]

def get_batches(items, size):
    for i in range(0, len(items), size):
        yield items[i:i + size]

def put_items(answers) -> None:
    # for each answer, update existing item if exists
    # this lets us group fqdns that resolve the same CIDR
    for cidr, answer in answers.items():
        fqdn = answer['fqdn']
        attribute_values = {
            ':expire_dt': {'S': answer['expire_dt']},
            ':expire_ts': {'N': str(answer['expire_ts'])},
            ':ttl_minutes': {'N': str(answer['ttl_minutes'])},
            ':fqdn': {'SS': fqdn}
        }
        expression = 'ADD fqdn :fqdn SET expire_dt=:expire_dt, expire_ts=:expire_ts, ttl_minutes=:ttl_minutes'
        ddb.update_item(
            TableName=TIMEOUT_TABLE_NAME,
            Key={'cidr': {'S': cidr}},
            UpdateExpression=expression,
            ExpressionAttributeValues=attribute_values
        )

def lambda_handler(event, context) -> None:
    """Sync network ACL with latest DNS query answers."""

    # Delete items from DynamoDB with expired TTL

    delete_expired_items()

    # Put latest query answers into DynamoDB table

    records = event['Records']
    put_items(get_answers(records))

    # Get the maximum number of items from DynamoDB table

    ddb_items = get_latest_items(100)  # set your max limit
    print(f'{len(ddb_items)} {ddb_items=}')

    # Create a map that we use later to get FQDNs

    cidr_map = {}
    for item in ddb_items:
        cidr_map[item['cidr']['S']] = item
    ddb_cidrs = set(cidr_map.keys())

    # Get existing entries so we can sync with DynamoDB table

    existing_entries = get_network_acl_entries(ACL_ID)
    existing_cidrs = {entry['CidrBlock'] for entry in existing_entries if 'CidrBlock' in entry}
    print(f'{len(existing_cidrs)} {existing_cidrs=}')

    highest_rule_number = get_highest_rule_number(existing_entries)

    # Remove entries from NACL that are not in latest items from DDB table
    remove_cidrs = existing_cidrs - ddb_cidrs
    remove_cidrs.discard('10.0.0.0/16')  # Ensure this CIDR is not removed
    remove_cidrs.discard('0.0.0.0/0')
    remove_entries = {entry['RuleNumber']: entry['CidrBlock'] for entry in existing_entries if entry['CidrBlock'] in remove_cidrs}
    print(f'{len(remove_entries)} {remove_entries=}')

    # Add entries from DDB table that don't already exist

    add_cidrs = ddb_cidrs - existing_cidrs
    add_entries = {highest_rule_number+i+1: {'Cidr': cidr, 'Description': str(cidr_map[cidr]['fqdn']['SS'])} for i, cidr in enumerate(add_cidrs)}
    print(f'{len(add_entries)} {add_entries=}')

    # Update the network ACL

    modify_network_acl(remove_entries=remove_entries)
    modify_network_acl(add_entries=add_entries)